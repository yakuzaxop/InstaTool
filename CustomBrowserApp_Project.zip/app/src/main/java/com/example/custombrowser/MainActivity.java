package com.example.custombrowser;

import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    // Direct links requested by user
    private final String SIGNUP_URL = "https://mail.td/";
    private final String LOGIN_URL = "https://www.instagram.com/accounts/login/";
    private final String HOME_URL = "https://accountscenter.instagram.com/manage/";
    private final String META_CONTACT_URL = "http://accountscenter.meta.com/account_overview/contact_points";
    private final String TWO_FACTOR_URL = "https://accountscenter.instagram.com/password_and_security/two_factor/?theme=dark";
    private final String AUTH_META_URL = "http://auth.meta.com/?waterfall_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);

        Button btnRefresh = findViewById(R.id.btnRefresh);
        Button btnSignUp = findViewById(R.id.btnSignUp);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnClearCookies = findViewById(R.id.btnClearCookies);
        Button btnNewTab = findViewById(R.id.btnNewTab);

        Button btnContactPoints = findViewById(R.id.btnContactPoints);
        Button btnTwoFactor = findViewById(R.id.btnTwoFactor);
        Button btnAuthMeta = findViewById(R.id.btnAuthMeta);

        // Configure WebView
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setUserAgentString("Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        webView.setWebViewClient(new WebViewClient());

        // Default Load URL
        webView.loadUrl(HOME_URL);

        // Button Actions
        btnRefresh.setOnClickListener(v -> webView.reload());
        btnSignUp.setOnClickListener(v -> webView.loadUrl(SIGNUP_URL));
        btnLogin.setOnClickListener(v -> webView.loadUrl(LOGIN_URL));
        btnContactPoints.setOnClickListener(v -> webView.loadUrl(META_CONTACT_URL));
        btnTwoFactor.setOnClickListener(v -> webView.loadUrl(TWO_FACTOR_URL));
        btnAuthMeta.setOnClickListener(v -> webView.loadUrl(AUTH_META_URL));

        btnClearCookies.setOnClickListener(v -> clearCookiesAndCache());

        btnNewTab.setOnClickListener(v -> {
            webView.loadUrl(HOME_URL);
            Toast.makeText(MainActivity.this, "New Tab Opened (Home Loaded)", Toast.LENGTH_SHORT).show();
        });
    }

    private void clearCookiesAndCache() {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.removeAllCookies(null);
        cookieManager.flush();

        webView.clearCache(true);
        webView.clearHistory();

        Toast.makeText(this, "Cookies, Cache & History Cleared!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
